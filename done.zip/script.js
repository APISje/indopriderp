document.addEventListener('DOMContentLoaded', () => {
  const welcomeOverlay = document.getElementById('welcome-overlay');
  const mainContent = document.getElementById('main-content');
  const enterBtn = document.getElementById('enter-btn');
  const bgMusic = document.getElementById('bg-music');
  const musicToggle = document.getElementById('music-toggle');
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navbar = document.querySelector('.navbar');
  const copyBtn = document.getElementById('copy-code');
  const serverCode = document.getElementById('server-code');
  const copySuccess = document.getElementById('copy-success');

  createWelcomeParticles();

  enterBtn.addEventListener('click', () => {
    bgMusic.volume = 0.3;
    bgMusic.play().catch(() => {
      console.log('Audio autoplay blocked - using fallback');
    });
    
    welcomeOverlay.style.opacity = '0';
    welcomeOverlay.style.transition = 'opacity 0.6s ease';
    
    setTimeout(() => {
      welcomeOverlay.style.display = 'none';
      mainContent.classList.remove('hidden');
      mainContent.style.opacity = '0';
      
      setTimeout(() => {
        mainContent.style.transition = 'opacity 0.6s ease';
        mainContent.style.opacity = '1';
        createHeroParticles();
        initScrollAnimations();
        initCounters();
      }, 50);
    }, 600);
  });

  let isMuted = false;
  musicToggle.addEventListener('click', () => {
    isMuted = !isMuted;
    bgMusic.muted = isMuted;
    musicToggle.innerHTML = isMuted ? 
      '<i class="fas fa-volume-mute"></i>' : 
      '<i class="fas fa-volume-up"></i>';
  });

  navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
  });

  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
      document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
      if (!link.classList.contains('join-nav')) {
        link.classList.add('active');
      }
    });
  });

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    const sections = document.querySelectorAll('section[id]');
    const scrollY = window.scrollY + 100;
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      
      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        document.querySelectorAll('.nav-link:not(.join-nav)').forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  });

  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(serverCode.textContent).then(() => {
      copyBtn.innerHTML = '<i class="fas fa-check"></i>';
      copySuccess.classList.add('show');
      
      setTimeout(() => {
        copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
        copySuccess.classList.remove('show');
      }, 2500);
    });
  });

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        const navHeight = navbar.offsetHeight;
        const targetPosition = targetElement.offsetTop - navHeight;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  function createWelcomeParticles() {
    const container = document.getElementById('welcome-particles');
    if (!container) return;
    
    for (let i = 0; i < 30; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.top = Math.random() * 100 + '%';
      particle.style.animationDelay = Math.random() * 3 + 's';
      particle.style.animationDuration = (3 + Math.random() * 4) + 's';
      particle.style.animation = `floatParticle ${3 + Math.random() * 4}s ease-in-out infinite`;
      container.appendChild(particle);
    }

    const style = document.createElement('style');
    style.textContent = `
      @keyframes floatParticle {
        0%, 100% { transform: translateY(0) translateX(0); opacity: 0.3; }
        50% { transform: translateY(-20px) translateX(10px); opacity: 0.6; }
      }
    `;
    document.head.appendChild(style);
  }

  function createHeroParticles() {
    const container = document.getElementById('hero-particles');
    if (!container) return;
    
    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.top = Math.random() * 100 + '%';
      particle.style.animation = `floatParticle ${4 + Math.random() * 5}s ease-in-out infinite`;
      particle.style.animationDelay = Math.random() * 2 + 's';
      container.appendChild(particle);
    }
  }

  function initScrollAnimations() {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            entry.target.classList.add('visible');
          }, index * 100);
        }
      });
    }, observerOptions);

    const animatedElements = document.querySelectorAll(
      '.fade-in-element, .slide-in-left, .slide-up-element, .scale-in-element'
    );
    
    animatedElements.forEach(el => {
      observer.observe(el);
    });
  }

  function initCounters() {
    const counters = document.querySelectorAll('.counter');
    
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const counter = entry.target;
          const target = parseInt(counter.getAttribute('data-target'));
          animateCounter(counter, target);
          counterObserver.unobserve(counter);
        }
      });
    }, { threshold: 0.5 });

    counters.forEach(counter => counterObserver.observe(counter));
  }

  function animateCounter(element, target) {
    const duration = 2000;
    const steps = 60;
    const stepValue = target / steps;
    let current = 0;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      current = Math.min(Math.round(stepValue * step), target);
      element.textContent = current.toLocaleString();
      
      if (step >= steps) {
        element.textContent = target.toLocaleString();
        clearInterval(timer);
      }
    }, duration / steps);
  }

  const deptCards = document.querySelectorAll('.dept-card');
  deptCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transition = 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
    });
  });

  const joinBoxes = document.querySelectorAll('.join-box');
  joinBoxes.forEach(box => {
    box.addEventListener('mouseenter', function() {
      this.style.transition = 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
    });
  });
});
